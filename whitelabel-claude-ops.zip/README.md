# affops

Claude Code operations repo for **movinslooow** and **parentslist.eu** — EU-EN conscious parenting sites (attachment parenting, sustainable family, Montessori). Self-hosted Ghost on Hetzner via Coolify. Phase-gated content and affiliate workflow orchestrated by Claude Code CLI.

---

## Entry Point

```bash
npm install -g @anthropic-ai/claude-code
cd affops
claude
```

Session start hook (`.claude/hooks/session-start.sh`) installs Python deps and prints priority todos. Context auto-loads via `.claude/settings.json → always_load`.

---

## Repo Layout

```
affops/
├── .claude/
│   ├── agents/          # editorial-checker, seo-analyst, technician
│   ├── commands/        # slash commands (see Commands table)
│   ├── skills/          # multi-step workflows (see Skills table)
│   ├── rules/           # phase-gates.md — enforced gate criteria
│   ├── hooks/           # session-start.sh, stop-dump-check.sh
│   └── settings.json    # permissions, hooks, always_load
├── context/             # tiered context (lvl1 auto, lvl2 on-demand, lvl3 explicit)
├── content/draft/       # article drafts
├── ghost/
│   └── scripts/         # publish.py (pages), publish-post.py (posts)
├── infra/
│   ├── ghost-api.env    # GHOST_URL, GHOST_ADMIN_KEY
│   ├── telegram-bot/    # long-poll Telegram bridge (VPS only)
│   └── systemd/         # affops-heartbeat.service + .timer
├── swarm/
│   ├── models.json      # provider + model routing (single source of truth)
│   ├── state.json       # agent counters
│   ├── scripts/         # spawn, dispatch, monitor, sync, cleanup, heartbeat
│   └── tasks/           # pending/ active/ done/ task JSON files
└── docker-compose.yml   # STALE — Ghost runs as Coolify direct service, not compose
```

---

## Context Tiers

| Tier | Load trigger | Files |
|------|-------------|-------|
| lvl1 | Every session (always_load) | `CLAUDE.md`, `lvl1-todo-session.md`, `lvl1-decisions.md` |
| lvl2 | On-demand when task needs it | `lvl2-keywords.md`, `lvl2-brand-voice.md`, `lvl2-brand-icp.md`, `lvl2-brand-philosophy.md`, `lvl2-content-pillars.md`, `lvl2-content-plan.md`, `lvl2-tech-stack.md`, `lvl2-todo-backlog.md` |
| lvl3 | Explicit request only | `lvl3-dump.md`, `lvl3-dump-archive.md`, `lvl3-decisions-archive.md` |

---

## Phase Gates

Defined in `.claude/rules/phase-gates.md`. Claude enforces gates; user can override explicitly.

| Phase | Gate to next | Allowed | Blocked |
|-------|-------------|---------|---------|
| 0: Setup | Site live + legal published | Setup, legal, keyword research | Publishing, SEO, paid traffic |
| 1: Content | 20+ articles | Writing, internal links, basic SEO | Link building, paid traffic |
| 2: Rank | 5 page-1 rankings + 1k sessions | Optimization, link building, technical SEO | Paid traffic, new clusters |
| 3: Monetize | $500/mo + EPC >$0.50 | CTA optimization, affiliate testing | New clusters, paid traffic |
| 4: Scale | — | New clusters, paid traffic, email | — |

---

## Commands

| Command | Args | Function |
|---------|------|----------|
| `/draft` | `[keyword]` | Draft article outline |
| `/qualify` | `[keyword]` | Score: volume × difficulty × intent |
| `/research` | `[topic]` | Research + save to insights |
| `/editorial-check` | `[file or text]` | Pre-publish gate (HWG, brand voice, ICP, keywords) |
| `/status` | — | Phase, todos, metrics |
| `/track` | `[keyword]` | SERP position check |
| `/analytics` | — | Metrics summary |
| `/competitors` | `[url]` | Competitor content + keyword analysis |
| `/trends` | `[keyword]` | Seasonal patterns |
| `/ghost-status` | — | List Ghost posts/pages (status, slug, URL) |
| `/publish` | `[file]` | Publish page/post to Ghost |

---

## Skills

| Skill | Triggers On | Notes |
|-------|------------|-------|
| `content-batch` | "content day", 2+ articles at once | Loads brand-voice + brand-icp |
| `content-optimize` | Improving rankings, underperformers | Loads brand-voice |
| `keyword-cluster` | "cluster keywords" | Groups by intent, outputs to lvl2-keywords.md |
| `recap` | "recap", "weekly review" | Metrics review + next-week priorities |
| `distill` | "distill", every 7–10 days | Signal extraction from lvl3-dump → lvl2 |
| `wrapup` | Session end, "wrap up" | Log decisions, update todos, trim context |

---

## Agents

| Agent | Role | Model |
|-------|------|-------|
| `editorial-checker` | Pre-publish QA: HWG compliance, brand voice, ICP, keywords | Sonnet |
| `seo-analyst` | SERP + keyword research | Haiku |
| `technician` | Config + maintenance sub-agent | Sonnet |

---

## Model Routing

Defined in `swarm/models.json` — single source of truth for provider + model per role.

| Role | Model | Used for |
|------|-------|---------|
| orchestrator | claude-opus-4-6 | Top-level planning, PR management |
| worker | claude-opus-4-6 | Content drafting (quality over speed) |
| analyst | claude-haiku-4-5 | Keyword research, SERP lookups |
| reviewer | claude-sonnet-4-6 | Post-mortems, editorial review |
| infra | claude-sonnet-4-6 | Orchestrator-initiated infra tasks |
| technician | claude-sonnet-4-6 | Delegated config/maintenance sub-agent |

Token caps and Telegram command → role mapping also live in `swarm/models.json`.

---

## Swarm (Parallel Execution)

```bash
./swarm/scripts/setup.sh      # create git worktrees
./swarm/scripts/spawn.sh      # launch Claude per worktree via tmux
./swarm/scripts/dispatch.sh batch 3  # write task JSON to tasks/pending/
./swarm/scripts/monitor.sh    # foreground task queue dashboard
./swarm/scripts/sync.sh       # merge worktree changes back
./swarm/scripts/cleanup.sh    # remove worktrees
```

Event-driven execution: `heartbeat.sh` fires pre-check gate → spawns LLM only when pending tasks exist. Avoids idle token burn.

---

## Permissions

Defined in `.claude/settings.json`.

**Allowed without confirmation:** `git` ops, Ghost Python scripts, swarm shell scripts, `Read / Write / Edit / Glob / Grep / WebFetch / WebSearch / Agent / Skill`

**Denied:** `rm -rf`, `curl`, reading `.env` / `.env.*` files

---

## Infrastructure

| Component | Detail |
|-----------|--------|
| VPS | Hetzner, Ubuntu |
| Deployment | Coolify (direct service — not docker-compose) |
| CMS | Ghost 5, self-hosted |
| DNS | Cloudflare (geo-block + AI crawler WAF rules) |
| SSL | Let's Encrypt via Coolify |
| Remote control | Telegram bot (`infra/telegram-bot/`) — long-poll bridge, VPS-only |
| Heartbeat | systemd user timer (`infra/systemd/affops-heartbeat.timer`) |

---

## Ghost SMTP Setup (Coolify)

Ghost runs as a Coolify one-click service. Mail config is split across two places:

**Service Specific Configuration (SSC)** handles the core fields:

| SSC Field | Value |
|-----------|-------|
| Mail User | `mail@parentslist.eu` |
| Mail Password | Flokinet webmail password for that account |
| Mail Host | `is3.flokinet.is` (not `mail.parentslist.eu` — cert is issued for this hostname) |
| Mail Port | `465` |
| Mail Secure | `true` (465 = direct SSL) |
| Mail Service | (leave empty) |

**Environment Variables tab** — add this manually alongside SSC (SSC has no field for it):

```
mail__from=parentslist <mail@parentslist.eu>
```

`mail__from` is required — Ghost refuses to send without a sender address.

**Why `is3.flokinet.is` as Mail Host:** `mail.parentslist.eu` is a CNAME to `is3.flokinet.is`. Flokinet's TLS cert is issued for `is3.flokinet.is`, not the CNAME. Using the CNAME as host causes an `ESOCKET` cert mismatch. Use the actual hostname the cert covers.

**After any env var change: full Redeploy, not restart.**

### Error code reference

| Code | Meaning | Fix |
|------|---------|-----|
| `ESOCKET` | TLS cert mismatch (CNAME vs actual hostname) | Use the hostname the cert is issued for, not the CNAME alias |
| `EAUTH` | Credentials rejected by SMTP server | Verify password in Flokinet webmail panel; avoid special chars |
| `ECONNREFUSED` / `ETIMEDOUT` | Port blocked | Request unblock at Hetzner console + Flokinet support |
| `Missing mail.from` warn | No sender address set | Add `mail__from` env var |
