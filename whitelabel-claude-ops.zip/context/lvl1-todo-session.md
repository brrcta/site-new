# Session TODOs

> Pull tasks here from lvl2-todo-backlog.md at the start of each session. Delete completed items — outcomes live in lvl1-decisions.md.

## NEXT SESSION

- [ ] Fill in all `{{PLACEHOLDER}}` vars in CLAUDE.md
- [ ] Complete context/lvl2-project.md (project context, success criteria, operating constraints)
- [ ] Customize .claude/rules/phase-gates.md for your project phases
- [ ] Customize .claude/hooks/session-start.sh — add your stack's dependency installs
- [ ] Add project-specific tech stack to context/lvl2-tech-stack.md
