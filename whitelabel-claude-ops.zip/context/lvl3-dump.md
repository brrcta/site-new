# Dump — Raw Inspiration & Reference

> Staging area for raw content, links, quotes, patterns. NOT always-loaded.
> Run `/distill` every 7-10 days to extract signal into permanent tier2 files.
> Format: `**raw:**` label followed by verbatim content, then `**signal:**` with 1–3 sentence insight.
